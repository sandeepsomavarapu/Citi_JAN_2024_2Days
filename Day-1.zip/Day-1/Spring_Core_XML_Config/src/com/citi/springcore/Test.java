package com.citi.springcore;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.citi.springcore.Employee;

public class Test {

	public static void main(String[] args) {
		Resource resource = new ClassPathResource("springconfig.xml");
		BeanFactory factory = new XmlBeanFactory(resource);
		Employee emp = (Employee) factory.getBean("emp1");
		System.out.println(emp);
		
		Employee emp1 = (Employee) factory.getBean("emp1");
		System.out.println(emp1);//scope-->singleton,prototype
		System.out.println(emp1.getAddress());
		
//		Address add = (Address) factory.getBean("add");
//		System.out.println(add);//scope-->singleton,prototype

	}

}
